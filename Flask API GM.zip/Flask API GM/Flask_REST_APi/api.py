from flask import Flask, request, jsonify, make_response
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import IntegrityError

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test_cases.db'
db = SQLAlchemy(app)

class TestCase(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)

class ExecutionResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    test_case_id = db.Column(db.Integer, db.ForeignKey('test_case.id'), nullable=False)
    test_asset = db.Column(db.String(100), nullable=False)
    result = db.Column(db.String(50), nullable=False)

with app.app_context():
    db.create_all()


# Endpoint to create a new test case
@app.route('/testcases', methods=['POST'])
def create_test_case():
    data = request.get_json()
    if 'name' not in data:
        return jsonify({'error': 'Name is required'}), 400

    name = data['name']
    description = data.get('description', None)

    # Check if the test case already exists
    existing_test_case = TestCase.query.filter_by(name=name).first()
    if existing_test_case:
        return jsonify({'error': 'Test case already exists'}), 400

    try:
        test_case = TestCase(name=name, description=description)
        db.session.add(test_case)
        db.session.commit()
        return jsonify({'message': 'Test case created successfully'}), 201
    except IntegrityError:
        db.session.rollback()
        return jsonify({'error': 'Test case already exists'}), 400

# Endpoint to retrieve all test cases
@app.route('/testcases', methods=['GET'])
def get_all_test_cases():
    test_cases = TestCase.query.all()
    output = []
    for test_case in test_cases:
        test_case_data = {'id': test_case.id, 'name': test_case.name, 'description': test_case.description}
        output.append(test_case_data)
    return jsonify({'test_cases': output})

# Endpoint to retrieve a single test case by its ID
@app.route('/testcases/<int:test_case_id>', methods=['GET'])
def get_test_case(test_case_id):
    test_case = TestCase.query.get(test_case_id)
    if test_case:
        test_case_data = {'id': test_case.id, 'name': test_case.name, 'description': test_case.description}
        return jsonify(test_case_data)
    else:
        return jsonify({'error': 'Test case not found'}), 404

# Endpoint to update an existing test case
@app.route('/testcases/<int:test_case_id>', methods=['PUT'])
def update_test_case(test_case_id):
    test_case = TestCase.query.get(test_case_id)
    if not test_case:
        return jsonify({'error': 'Test case not found'}), 404

    data = request.get_json()
    if 'name' in data:
        test_case.name = data['name']
    if 'description' in data:
        test_case.description = data['description']

    db.session.commit()
    return jsonify({'message': 'Test case updated successfully'})

# Endpoint to delete a test case by its ID
@app.route('/testcases/<int:test_case_id>', methods=['DELETE'])
def delete_test_case(test_case_id):
    test_case = TestCase.query.get(test_case_id)
    if not test_case:
        return jsonify({'error': 'Test case not found'}), 404

    db.session.delete(test_case)
    db.session.commit()
    return jsonify({'message': 'Test case deleted successfully'})

# Endpoint to record the execution result of a test case for a specific test asset
@app.route('/execute', methods=['POST'])
def record_execution_result():
    data = request.get_json()
    if not all(key in data for key in ['test_case_id', 'test_asset', 'result']):
        return jsonify({'error': 'Missing required parameters'}), 400

    test_case_id = data['test_case_id']
    test_asset = data['test_asset']
    result = data['result']

    execution_result = ExecutionResult(test_case_id=test_case_id, test_asset=test_asset, result=result)
    db.session.add(execution_result)
    db.session.commit()

    return jsonify({'message': 'Execution result recorded successfully'}), 201

# Endpoint to retrieve the execution results of all test cases for a specific test asset
@app.route('/execute/<string:test_asset>', methods=['GET'])
def get_execution_results(test_asset):
    execution_results = ExecutionResult.query.filter_by(test_asset=test_asset).all()
    if not execution_results:
        return jsonify({'message': 'No execution results found for the test asset'})

    output = []
    for result in execution_results:
        result_data = {'test_case_id': result.test_case_id, 'result': result.result}
        output.append(result_data)

    return jsonify({'execution_results': output})

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
