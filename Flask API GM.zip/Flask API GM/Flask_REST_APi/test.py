import unittest
import json
from api import app, db, TestCase, ExecutionResult
from flask import current_app


class TestAppEndpoints(unittest.TestCase):

    # Set up and tear down methods
    def setUp(self):
        self.app_context = app.app_context()
        self.app_context.push()
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
        self.app = app.test_client()
        db.create_all()


    def tearDown(self):
        db.session.remove()
        db.drop_all()
        self.app_context.pop()


    # Test cases for endpoint /testcases
    def test_create_test_case(self):
        test_case_data = {'name': 'Test Case 1', 'description': 'Description for test case 1'}
        response = self.app.post('/testcases', json=test_case_data)
        data = json.loads(response.data.decode())

        self.assertEqual(response.status_code, 201)
        self.assertEqual(data['message'], 'Test case created successfully')

    def test_create_test_case_missing_name(self):
        test_case_data = {'description': 'Description for test case 1'}
        response = self.app.post('/testcases', json=test_case_data)
        data = json.loads(response.data.decode())

        self.assertEqual(response.status_code, 400)
        self.assertIn('error', data)

    def test_create_duplicate_test_case(self):
        test_case_data = {'name': 'Test Case 1', 'description': 'Description for test case 1'}
        self.app.post('/testcases', json=test_case_data)

        response = self.app.post('/testcases', json=test_case_data)
        data = json.loads(response.data.decode())

        self.assertEqual(response.status_code, 400)
        self.assertIn('error', data)

    def test_get_all_test_cases_empty(self):
        response = self.app.get('/testcases')
        data = json.loads(response.data.decode())

        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(data['test_cases']), 0)    

    # Test cases for endpoint /testcases/<test_case_id>
    def test_retrieve_existing_test_case(self):
        test_case = TestCase(name='Test Case test', description='Description for test case test')
        db.session.add(test_case)
        db.session.commit()

        response = self.app.get(f'/testcases/{test_case.id}')
        data = json.loads(response.data.decode())

        self.assertEqual(response.status_code, 200)
        self.assertEqual(data['name'], 'Test Case test')

    def test_retrieve_non_existing_test_case(self):
        response = self.app.get('/testcases/1000')
        data = json.loads(response.data.decode())

        self.assertEqual(response.status_code, 404)
        self.assertIn('error', data)

    def test_update_existing_test_case(self):
        # Create a test case
        test_case = TestCase(name='Test Case test2', description='Description for test case test2')
        db.session.add(test_case)
        db.session.commit()

        update_data = {'name': 'Updated Test Case', 'description': 'Updated description'}

        response = self.app.put(f'/testcases/{test_case.id}', json=update_data)
        data = json.loads(response.data.decode())

        self.assertEqual(response.status_code, 200)
        self.assertEqual(data['message'], 'Test case updated successfully')

        # Verify that the test case has been updated
        updated_test_case = TestCase.query.get(test_case.id)
        self.assertEqual(updated_test_case.name, 'Updated Test Case')
        self.assertEqual(updated_test_case.description, 'Updated description')

    def test_update_non_existing_test_case(self):
        update_data = {'name': 'Updated Test Case', 'description': 'Updated description'}

        response = self.app.put('/testcases/1000', json=update_data)
        data = json.loads(response.data.decode())

        self.assertEqual(response.status_code, 404)
        self.assertIn('error', data)

    def test_delete_existing_test_case(self):
        # Create a test case
        test_case = TestCase(name='Test Case delete', description='Description for test case delete')
        db.session.add(test_case)
        db.session.commit()

        response = self.app.delete(f'/testcases/{test_case.id}')
        data = json.loads(response.data.decode())

        self.assertEqual(response.status_code, 200)
        self.assertEqual(data['message'], 'Test case deleted successfully')

        # Verify that the test case has been deleted
        deleted_test_case = TestCase.query.get(test_case.id)
        self.assertIsNone(deleted_test_case)

    # Test cases for endpoint /execute
    def test_delete_non_existing_test_case(self):
        response = self.app.delete('/testcases/1000')
        data = json.loads(response.data.decode())

        self.assertEqual(response.status_code, 404)
        self.assertIn('error', data)    
    
    def test_record_execution_result(self):
        # Test recording the execution result of a test case with valid data
        data = {'test_case_id': 1, 'test_asset': 'asset1', 'result': 'pass'}
        response = self.app.post('/execute', json=data)
        self.assertEqual(response.status_code, 201)

    def test_record_execution_result_missing_parameters(self):
        # Test recording the execution result of a test case with missing parameters
        data = {'test_case_id': 1, 'result': 'pass'}
        response = self.app.post('/execute', json=data)
        self.assertEqual(response.status_code, 400)

    def test_get_execution_results_existing_results(self):
        # Inserting some execution results into the database for testing
        result1 = ExecutionResult(test_case_id=1, test_asset='asset1', result='pass')
        result2 = ExecutionResult(test_case_id=2, test_asset='asset1', result='fail')
        db.session.add(result1)
        db.session.add(result2)
        db.session.commit()

        # Test retrieving execution results for a specific test asset with existing results
        response = self.app.get('/execute/asset1')
        data = json.loads(response.data.decode())
        self.assertEqual(response.status_code, 200)
        self.assertTrue('execution_results' in data)
        self.assertEqual(len(data['execution_results']), 2)

    def test_get_execution_results_no_results(self):
        # Test retrieving execution results for a specific test asset with no results
        response = self.app.get('/execute/non_existing_asset')
        data = json.loads(response.data.decode())
        self.assertEqual(response.status_code, 200)
        self.assertTrue('message' in data)
        self.assertEqual(data['message'], 'No execution results found for the test asset')

    def test_get_execution_results_non_existing_asset(self):
        # Test retrieving execution results for a non-existing test asset
        response = self.app.get('/execute/non_existing_asset')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data.decode())
        self.assertTrue('message' in data)
        self.assertEqual(data['message'], 'No execution results found for the test asset')

if __name__ == '__main__':
     unittest.main()
